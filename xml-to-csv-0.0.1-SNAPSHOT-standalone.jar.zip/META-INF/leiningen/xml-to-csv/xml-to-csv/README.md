# xml-to-csv

A Clojure app to convert an XML file to
a two-column CSV file, with a concatenated string
of tags in the left column and values in the
right column.

## Usage

Command line:

    cd /path/to/the/xml_to_csv-0.0.1-SNAPSHOT-standalone.jar
    java -jar xml_to_csv-0.0.1-SNAPSHOT-standalone.jar your_file.xml
